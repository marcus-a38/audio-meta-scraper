from ..src.audio import search, analyze_futures, get_drives
from typing import Callable, NamedTuple
from pathlib import Path

def run_ps_test():
    get_drives()

def run_search_tests(**kwargs):

    path = kwargs.get('path')

    recurs = analyze_futures(search_results=search(path), is_recursive=True)
    print("[Test] Recursive search test complete.")

    nrecur = analyze_futures(search_results=search(path), is_recursive=False)
    print("[Test] Non-recursive search test complete.")

    system = analyze_futures(search_results=search(Path('.')), is_recursive=True)
    print("[Test] System search test complete.")

    print("[Test] Verifying results...")
    assert list(recurs) == kwargs.get('r'), kwargs.get('r-debug')
    assert list(nrecur) == kwargs.get('n'), kwargs.get('n-debug')
    assert list(system) == kwargs.get('s'), kwargs.get('s-debug')
    print("[Test] All tests successful.")
    

def main():

    test_kwargs = {
        'path': '',
        'r': '',
        'n': '',
        's': '',
        'r-debug': '',
        'n-debug': '',
        's-debug': ''
    }

    run_search_tests(test_kwargs)


if __name__ == "__main__":

    run_ps_test()